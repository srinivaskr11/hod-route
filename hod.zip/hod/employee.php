<?php
require('top.inc.php');
require('upload.php');
if($_SESSION['ROLE']!=1){
	header('location:add_employee.php?id='.$_SESSION['USER_ID']);
	die();
}
if(isset($_GET['type']) && $_GET['type']=='delete' && isset($_GET['id'])){
	$id=mysqli_real_escape_string($con,$_GET['id']);
	mysqli_query($con,"delete from employee where id='$id'");
}
$res=mysqli_query($con,"select * from employee where role=2 order by id desc");
?>
<div class="content pb-0">
            <div class="orders">
               <div class="row">
                  <div class="col-xl-12">
                     <div class="card">
                        <div class="card-body">
                           <h4 class="box-title">Upload Documents </h4>
						   <h4 class="box_title_link">Upload </h4>
                        </div>
												<form class="" action="upload.php" method="post" enctype="multipart/form-data">
													<input type="file" name="my_image" value="">
													<button type="submit" name="submit"><strong>UPLOAD</strong></button>

												</form>

                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>



<?php
require('footer.inc.php');
?>
